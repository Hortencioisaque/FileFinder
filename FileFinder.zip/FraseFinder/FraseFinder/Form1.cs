﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FraseFinder
{
    public partial class Form1 : Form
    {
        List<string> ExtList = new List<string>();
        int fileCounter = 0;
        public Form1()
        {
            InitializeComponent();
        }
        private void FolderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        { }
        private void TextBox2_TextChanged(object sender, EventArgs e)
        { }
        private void Label5_Click(object sender, EventArgs e)
        { }
        private void TextBox3_TextChanged(object sender, EventArgs e)
        { }
        private void Button1_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            textBox3.Text = folderBrowserDialog1.SelectedPath;
        }
        private void TextBox1_TextChanged(object sender, EventArgs e)
        { }
        private void Button2_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(textBox3.Text))
            {
                if (!String.IsNullOrEmpty(textBox2.Text))
                {
                    if (!String.IsNullOrEmpty(textBox1.Text))
                    {
                        foreach (string file in Directory.EnumerateFiles(textBox3.Text))
                        {
                            fileCounter++;

                            string extension = Path.GetExtension(file);
                            string contents = File.ReadAllText(file);

                            if (extension == textBox2.Text)
                            {
                                string strcontents = File.ReadAllText(file);
                                if (strcontents.Contains(textBox1.Text))
                                {
                                    richTextBox1.AppendText(file.PadRight(55) + "                  -                     Found      " + Environment.NewLine );
                                }
                                else
                                {
                                    richTextBox1.AppendText(file.PadRight(85) + "                  -                     Not Found :     " + Environment.NewLine );
                                }
                            }
                            else
                            {
                                if (fileCounter == 1)
                                {
                                    richTextBox1.AppendText("No Files were Found With The Extension of  '" + textBox2.Text + "'  " + Environment.NewLine );
                                }
                                if (!ExtList.Contains(extension))
                                {
                                    ExtList.Add(extension);
                                    richTextBox1.AppendText(" Other Extensoin found:   " + extension + "     " + Environment.NewLine );
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("'Search For' field is empty, Please enter a Value");
                    }
                }
                else
                {
                    MessageBox.Show("'File Extension', is missing Please specify the extension");
                }
            }
            else
            {
                MessageBox.Show("'Folder Path is missing', Please enter or search for a the folder path.");
            }
        }
        private void RichTextBox1_TextChanged(object sender, EventArgs e)
        { }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
